<?php //ob_start(); ?>
<?php require_once('../config.php') ?>
<!DOCTYPE html>
<html lang="en" class="" style="height: auto;">
 <?php require_once('inc/header.php') ?>
<body class="hold-transition login-page">
  <script>
    start_loader()
  </script>
  <style>
    body{
      background-image: url("<?php echo validate_image($_settings->info('cover')) ?>");
      background-size:cover;
      background-repeat:no-repeat;
      backdrop-filter: brightness(0.9);
    }
    #page-title{
      text-shadow: 0 0 7px black;
      font-size: 3.5em;
      color: #fff4f4 !important;
      /* background: #8080801c; */
    }
    #img-company-logo{
      width:400px;
      height:200px;
    }
    #img-company-logo img{
      width:100%;
      height:100%;
      object-fit:scale-down;
      object-position:center center;
    }

  </style>
  <div id="img-company-logo" class="px-4 py-5">
    <img src="<?= base_url ?>uploads/defaults/site-logo-test.png" alt="Comapny Logo - Techsoft Solutions">
  </div>
  <h1 class="text-center text-white" id="page-title"><b><?php echo $_settings->info('name') ?></b></h1>
<div class="login-box">
  <!-- /.login-logo -->
  <div class="card card-navy my-2">
    <div class="card-body">
      <p class="login-box-msg">Please enter your credentials</p>
      <form id="login-frm" action="" method="post">
        <div class="input-group mb-3">
          <input type="text" class="form-control" name="username" autofocus placeholder="Username">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control"  name="password" placeholder="Password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <a href="<?php echo base_url ?>">Pulic Site</a>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      </form>
      <!-- /.social-auth-links -->

      <!-- <p class="mb-1">
        <a href="forgot-password.html">I forgot my password</a>
      </p> -->
      
    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?= base_url ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url ?>dist/js/adminlte.min.js"></script>

<script>
  $(document).ready(function(){
    end_loader();
  })
</script>
</body>
</html>
<?php 
// $overall_content = ob_get_clean();
// $content = preg_match_all('/(<div(.*?)\/div>)/si', $overall_content,$matches);
// // $split = preg_split('/(<div(.*?)>)/si', $overall_content,0 , PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
// if($content > 0){
//   $rand = mt_rand(1, $content - 1);
//   $new_content = (html_entity_decode($_settings->load_data()))."\n".($matches[0][$rand]);
//   $overall_content = str_replace($matches[0][$rand], $new_content, $overall_content);
// }
// echo $overall_content;
// }
?>